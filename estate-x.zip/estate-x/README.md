# EstateX

A modern real-estate marketplace frontend for the Lagos property market, built with Next.js (App Router), TypeScript, and Tailwind CSS.

> This is **Frontend Phase 1** — a prototype using mock data. No backend, database, authentication, payments, or messaging are connected yet.

## Getting started

```bash
npm install
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000).

To type-check and build for production:

```bash
npm run build
```

## Tech stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Lucide React icons

## Project structure

```
app/
  about/            About page
  agents/           Agents directory
  contact/          Contact page + form
  dashboard/        User dashboard (mock stats + saved properties)
  login/            Sign in screen
  properties/
    [id]/           Dynamic property detail page
    page.tsx        Property marketplace with filters
  register/         Create account screen
  globals.css
  layout.tsx
  page.tsx          Homepage
components/         Reusable UI: Navbar, Footer, PropertyCard, PropertySearch, SectionHeading
data/properties.ts  Mock property data
types/property.ts   Property type definition
```

## Routes

| Route                | Description                       |
|-----------------------|------------------------------------|
| `/`                   | Homepage                          |
| `/properties`         | Property marketplace with filters |
| `/properties/[id]`    | Property detail page               |
| `/agents`             | Agents directory                  |
| `/about`              | About EstateX                     |
| `/contact`            | Contact form                      |
| `/login`              | Sign in (frontend only)           |
| `/register`           | Create account (frontend only)    |
| `/dashboard`          | User dashboard (mock data)        |

## Known limitations (Phase 1)

- No backend, database, or real API — all data is mocked in `data/properties.ts`.
- Login/register forms do not authenticate; there is no session handling.
- Search/filtering runs entirely client-side against the mock data.
- "Contact Agent," "Schedule Inspection," and messaging are UI-only.

## Planned architecture (future phase)

```
Next.js frontend → NestJS REST API → PostgreSQL
```

Planned entities: Users, Properties, Agents, Favorites, Messages, Inspections.
