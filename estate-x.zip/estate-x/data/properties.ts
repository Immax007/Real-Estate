import { Property } from "@/types/property";

export const properties: Property[] = [
  {
    id: 1,
    title: "Modern Luxury Duplex",
    location: "Lekki Phase 1",
    city: "Lagos",
    price: 85000000,
    priceLabel: "₦85m",
    type: "House",
    listingType: "For Sale",
    bedrooms: 4,
    bathrooms: 5,
    area: "450 sqm",
    image:
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80",
    description:
      "A striking contemporary duplex set within a gated estate in Lekki Phase 1. Finished to a premium standard with double-height living spaces, a fitted kitchen with imported cabinetry, en-suite bedrooms, a private study, and a landscaped rear garden. Ideal for a family seeking space, security, and easy access to the Lekki-Epe corridor.",
    featured: true,
  },
  {
    id: 2,
    title: "Contemporary Family Home",
    location: "Ikoyi",
    city: "Lagos",
    price: 120000000,
    priceLabel: "₦120m",
    type: "House",
    listingType: "For Sale",
    bedrooms: 5,
    bathrooms: 6,
    area: "600 sqm",
    image:
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=80",
    description:
      "An expansive five-bedroom home on one of Ikoyi's quiet, tree-lined streets. The residence features a formal dining room, a family lounge opening onto a covered terrace, a home cinema, staff quarters, and a two-car garage. Walking distance to top international schools and the Ikoyi Club.",
    featured: true,
  },
  {
    id: 3,
    title: "Elegant Garden Villa",
    location: "Ajah",
    city: "Lagos",
    price: 65000000,
    priceLabel: "₦65m",
    type: "Villa",
    listingType: "For Sale",
    bedrooms: 4,
    bathrooms: 4,
    area: "500 sqm",
    image:
      "https://images.unsplash.com/photo-1613977257363-707ba9348227?w=1200&q=80",
    description:
      "A serene garden villa in a fast-growing Ajah neighbourhood, offering generous outdoor space, a private swimming pool, and a bright open-plan living and dining area. Close to shopping centres, schools, and the Lekki-Epe expressway, with plenty of room for a growing family.",
    featured: true,
  },
  {
    id: 4,
    title: "Luxury City Apartment",
    location: "Victoria Island",
    city: "Lagos",
    price: 8500000,
    priceLabel: "₦8.5m/year",
    type: "Apartment",
    listingType: "For Rent",
    bedrooms: 3,
    bathrooms: 3,
    area: "220 sqm",
    image:
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200&q=80",
    description:
      "A fully serviced three-bedroom apartment on Victoria Island, moments from major banks, corporate headquarters, and waterfront restaurants. Comes with 24-hour power, a fitted gym, secure parking, and round-the-clock estate security — built for professionals who want city living without compromise.",
    featured: false,
  },
  {
    id: 5,
    title: "Executive Penthouse",
    location: "Banana Island",
    city: "Lagos",
    price: 180000000,
    priceLabel: "₦180m",
    type: "Apartment",
    listingType: "For Sale",
    bedrooms: 4,
    bathrooms: 5,
    area: "520 sqm",
    image:
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=80",
    description:
      "A statement penthouse on Banana Island with panoramic lagoon views, a private elevator lobby, floor-to-ceiling glazing, and a wraparound terrace built for entertaining. Finished with imported marble, smart-home controls, and access to the estate's private marina.",
    featured: true,
  },
  {
    id: 6,
    title: "Modern Family Apartment",
    location: "Yaba",
    city: "Lagos",
    price: 3500000,
    priceLabel: "₦3.5m/year",
    type: "Apartment",
    listingType: "For Rent",
    bedrooms: 2,
    bathrooms: 2,
    area: "150 sqm",
    image:
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&q=80",
    description:
      "A well-maintained two-bedroom apartment in the heart of Yaba, close to tech hubs, universities, and the mainland's busiest transport links. Features a modern kitchen, tiled interiors, and a shared compound with backup power and gated access.",
    featured: false,
  },
];
