type SectionHeadingProps = {
  eyebrow?: string;
  heading: string;
  description?: string;
  align?: "left" | "center";
};

export default function SectionHeading({
  eyebrow,
  heading,
  description,
  align = "left",
}: SectionHeadingProps) {
  return (
    <div className={align === "center" ? "text-center mx-auto max-w-2xl" : ""}>
      {eyebrow && (
        <div
          className={`flex items-center gap-2 mb-3 ${
            align === "center" ? "justify-center" : ""
          }`}
        >
          <span className="h-1.5 w-1.5 rounded-full bg-orange" />
          <span className="text-sm font-semibold text-orange">{eyebrow}</span>
        </div>
      )}
      <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-dark">
        {heading}
      </h2>
      {description && (
        <p className="mt-3 text-base text-slate-600 leading-relaxed">
          {description}
        </p>
      )}
    </div>
  );
}
