"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Bed, Bath, Ruler, Heart, MapPin, ArrowRight } from "lucide-react";
import { Property } from "@/types/property";

export default function PropertyCard({ property }: { property: Property }) {
  const [saved, setSaved] = useState(false);

  return (
    <div className="group rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-card hover:shadow-cardHover transition-shadow duration-300">
      <div className="relative h-56 w-full overflow-hidden">
        <Image
          src={property.image}
          alt={property.title}
          fill
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          className="object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <span className="absolute top-3 left-3 rounded-md bg-white/95 px-2.5 py-1 text-xs font-semibold text-dark shadow-sm">
          {property.listingType}
        </span>
        <button
          type="button"
          aria-label={saved ? "Remove from saved" : "Save property"}
          aria-pressed={saved}
          onClick={() => setSaved((v) => !v)}
          className="absolute top-3 right-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/95 shadow-sm hover:bg-white transition-colors"
        >
          <Heart
            size={17}
            className={saved ? "fill-orange text-orange" : "text-slate-500"}
          />
        </button>
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-base font-semibold text-dark leading-snug">
            {property.title}
          </h3>
        </div>

        <p className="mt-1.5 flex items-center gap-1.5 text-sm text-slate-500">
          <MapPin size={14} />
          {property.location}, {property.city}
        </p>

        <p className="mt-3 text-lg font-bold text-orange">
          {property.priceLabel}
        </p>

        <div className="mt-4 flex items-center gap-4 text-sm text-slate-600 border-t border-slate-100 pt-4">
          <span className="flex items-center gap-1.5">
            <Bed size={16} className="text-slate-400" />
            {property.bedrooms}
          </span>
          <span className="flex items-center gap-1.5">
            <Bath size={16} className="text-slate-400" />
            {property.bathrooms}
          </span>
          <span className="flex items-center gap-1.5">
            <Ruler size={16} className="text-slate-400" />
            {property.area}
          </span>
        </div>

        <Link
          href={`/properties/${property.id}`}
          className="mt-5 flex items-center justify-center gap-1.5 w-full rounded-lg border border-slate-200 py-2.5 text-sm font-semibold text-dark hover:bg-orange hover:text-white hover:border-orange transition-colors"
        >
          View Property
          <ArrowRight size={15} />
        </Link>
      </div>
    </div>
  );
}
