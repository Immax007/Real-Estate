"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";
import { MapPin, Building2, Tag, Search } from "lucide-react";

const propertyTypes = ["Any Type", "Apartment", "House", "Villa", "Land", "Commercial"];
const purposes = ["Buy", "Rent", "Shortlet"];

export default function PropertySearch({ className = "" }: { className?: string }) {
  const router = useRouter();
  const [location, setLocation] = useState("");
  const [type, setType] = useState(propertyTypes[0]);
  const [purpose, setPurpose] = useState(purposes[0]);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (location.trim()) params.set("location", location.trim());
    if (type !== "Any Type") params.set("type", type);
    params.set("purpose", purpose);
    router.push(`/properties?${params.toString()}`);
  }

  return (
    <form
      onSubmit={handleSubmit}
      className={`bg-white rounded-2xl shadow-cardHover border border-slate-100 p-3 sm:p-4 ${className}`}
    >
      <div className="flex flex-col sm:flex-row gap-3">
        <label className="flex-1 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
          <MapPin size={18} className="text-slate-400 shrink-0" />
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Location, e.g. Lekki"
            className="w-full text-sm outline-none placeholder:text-slate-400 bg-transparent"
          />
        </label>

        <label className="flex-1 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
          <Building2 size={18} className="text-slate-400 shrink-0" />
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="w-full text-sm outline-none bg-transparent text-dark"
          >
            {propertyTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </label>

        <label className="flex-1 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
          <Tag size={18} className="text-slate-400 shrink-0" />
          <select
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            className="w-full text-sm outline-none bg-transparent text-dark"
          >
            {purposes.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </label>

        <button
          type="submit"
          className="flex items-center justify-center gap-2 rounded-xl bg-orange hover:bg-orange-600 transition-colors text-white text-sm font-semibold px-6 py-3 shrink-0"
        >
          <Search size={17} />
          Search
        </button>
      </div>
    </form>
  );
}
