import Link from "next/link";
import { Home, MapPin, Mail, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-dark text-slate-300">
      <div className="container-x py-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <Link href="/" className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange text-white">
              <Home size={18} strokeWidth={2.5} />
            </span>
            <span className="text-lg font-bold text-white">
              Estate<span className="text-orange">X</span>
            </span>
          </Link>
          <p className="mt-4 text-sm text-slate-400 max-w-xs">
            Find a place you&apos;ll love.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-4">Explore</h4>
          <ul className="space-y-3 text-sm">
            <li>
              <Link href="/properties" className="hover:text-orange transition-colors">
                Properties
              </Link>
            </li>
            <li>
              <Link href="/agents" className="hover:text-orange transition-colors">
                Agents
              </Link>
            </li>
            <li>
              <Link href="/about" className="hover:text-orange transition-colors">
                About
              </Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-orange transition-colors">
                Contact
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-4">For Agents</h4>
          <ul className="space-y-3 text-sm">
            <li>
              <Link href="/register" className="hover:text-orange transition-colors">
                List a Property
              </Link>
            </li>
            <li>
              <Link href="/dashboard" className="hover:text-orange transition-colors">
                Agent Dashboard
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-4">Contact</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-2">
              <MapPin size={16} className="mt-0.5 text-orange shrink-0" />
              <span>Lagos, Nigeria</span>
            </li>
            <li className="flex items-start gap-2">
              <Mail size={16} className="mt-0.5 text-orange shrink-0" />
              <span>hello@estatex.ng</span>
            </li>
            <li className="flex items-start gap-2">
              <Phone size={16} className="mt-0.5 text-orange shrink-0" />
              <span>+234 801 234 5678</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-x py-6 text-xs text-slate-500 flex flex-col sm:flex-row gap-2 sm:justify-between">
          <span>© {new Date().getFullYear()} EstateX. All rights reserved.</span>
          <span>Built for the Lagos property market.</span>
        </div>
      </div>
    </footer>
  );
}
