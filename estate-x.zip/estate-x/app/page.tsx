import Image from "next/image";
import Link from "next/link";
import { ShieldCheck, Building, Users, ArrowRight } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertySearch from "@/components/PropertySearch";
import PropertyCard from "@/components/PropertyCard";
import SectionHeading from "@/components/SectionHeading";
import { properties } from "@/data/properties";

const categories = [
  {
    label: "Apartments",
    query: "Apartment",
    image:
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80",
  },
  {
    label: "Houses",
    query: "House",
    image:
      "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800&q=80",
  },
  {
    label: "Luxury Villas",
    query: "Villa",
    image:
      "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&q=80",
  },
  {
    label: "Land",
    query: "Land",
    image:
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80",
  },
];

export default function HomePage() {
  const featured = properties.filter((p) => p.featured);

  return (
    <>
      <Navbar />

      {/* Hero */}
      <section className="relative isolate">
        <div className="absolute inset-0 -z-10">
          <Image
            src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1920&q=80"
            alt="Modern home exterior in Lagos"
            fill
            priority
            className="object-cover"
          />
          <div className="absolute inset-0 bg-dark/70" />
          <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-dark/40 to-dark/60" />
        </div>

        <div className="container-x pt-20 pb-28 sm:pt-28 sm:pb-36">
          <div className="max-w-2xl">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.1]">
              Find a place you&apos;ll love.
            </h1>
            <p className="mt-5 text-base sm:text-lg text-slate-200 max-w-xl">
              Discover beautiful homes, apartments, land and commercial
              properties from trusted agents across Lagos.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/properties"
                className="inline-flex items-center gap-2 rounded-lg bg-orange hover:bg-orange-600 transition-colors text-white text-sm font-semibold px-6 py-3.5"
              >
                Browse Properties
                <ArrowRight size={16} />
              </Link>
              <Link
                href="/register"
                className="inline-flex items-center gap-2 rounded-lg bg-white/10 border border-white/30 hover:bg-white/20 transition-colors text-white text-sm font-semibold px-6 py-3.5"
              >
                List a Property
              </Link>
            </div>
          </div>
        </div>

        <div className="container-x -mt-14 sm:-mt-16 relative pb-2">
          <PropertySearch />
        </div>
      </section>

      {/* Trust features */}
      <section className="border-b border-slate-100">
        <div className="container-x py-14 grid grid-cols-1 sm:grid-cols-3 gap-8">
          <div className="flex items-start gap-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-orange">
              <ShieldCheck size={22} />
            </span>
            <div>
              <h3 className="font-semibold text-dark">Verified Properties</h3>
              <p className="mt-1 text-sm text-slate-600">
                Every listing is checked before it goes live.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-orange">
              <Building size={22} />
            </span>
            <div>
              <h3 className="font-semibold text-dark">Thousands of Listings</h3>
              <p className="mt-1 text-sm text-slate-600">
                From studio apartments to full estates across Lagos.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-orange">
              <Users size={22} />
            </span>
            <div>
              <h3 className="font-semibold text-dark">Professional Agents</h3>
              <p className="mt-1 text-sm text-slate-600">
                Work with agents who know the local market inside out.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured properties */}
      <section className="py-16 sm:py-20">
        <div className="container-x">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
            <SectionHeading
              eyebrow="Handpicked"
              heading="Featured properties"
              description="A selection of our most sought-after listings this month."
            />
            <Link
              href="/properties"
              className="hidden sm:inline-flex items-center gap-1.5 text-sm font-semibold text-orange shrink-0"
            >
              View all properties
              <ArrowRight size={15} />
            </Link>
          </div>

          <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featured.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>

          <Link
            href="/properties"
            className="sm:hidden mt-8 flex items-center justify-center gap-1.5 text-sm font-semibold text-orange"
          >
            View all properties
            <ArrowRight size={15} />
          </Link>
        </div>
      </section>

      {/* Browse by type */}
      <section className="py-16 sm:py-20 bg-slate-50 border-y border-slate-100">
        <div className="container-x">
          <SectionHeading
            eyebrow="Categories"
            heading="Browse by property type"
            description="Looking for something specific? Start with a category."
          />

          <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {categories.map((cat) => (
              <Link
                key={cat.label}
                href={`/properties?type=${encodeURIComponent(cat.query)}`}
                className="group relative h-40 sm:h-52 rounded-2xl overflow-hidden"
              >
                <Image
                  src={cat.image}
                  alt={cat.label}
                  fill
                  sizes="(max-width: 768px) 50vw, 25vw"
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-dark/10 to-transparent" />
                <span className="absolute bottom-4 left-4 text-white font-semibold text-sm sm:text-base">
                  {cat.label}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* List your property CTA */}
      <section className="py-16 sm:py-20">
        <div className="container-x">
          <div className="rounded-2xl bg-orange px-6 py-12 sm:px-14 sm:py-16 text-center sm:text-left sm:flex sm:items-center sm:justify-between gap-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white max-w-lg">
                Have a property to list?
              </h2>
              <p className="mt-3 text-sm sm:text-base text-orange-50 max-w-md">
                Reach thousands of verified buyers and tenants searching for
                their next home across Lagos.
              </p>
            </div>
            <Link
              href="/register"
              className="mt-6 sm:mt-0 inline-flex items-center gap-2 rounded-lg bg-white hover:bg-orange-50 transition-colors text-orange text-sm font-semibold px-6 py-3.5 shrink-0"
            >
              List a Property
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
