"use client";

import Link from "next/link";
import { FormEvent } from "react";
import { Home, User, Mail, Lock } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function RegisterPage() {
  function handleSubmit(e: FormEvent) {
    e.preventDefault();
  }

  return (
    <>
      <Navbar />
      <section className="container-x py-14 sm:py-20 flex justify-center">
        <div className="w-full max-w-md">
          <div className="flex flex-col items-center text-center">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange text-white mb-4">
              <Home size={20} strokeWidth={2.5} />
            </span>
            <h1 className="text-2xl font-bold text-dark">Create your account</h1>
            <p className="mt-2 text-sm text-slate-500">
              Join EstateX to save properties and list with agents.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div>
              <label htmlFor="name" className="text-sm font-medium text-dark">
                Full name
              </label>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
                <User size={17} className="text-slate-400" />
                <input
                  id="name"
                  type="text"
                  required
                  placeholder="Ada Okafor"
                  className="w-full text-sm outline-none placeholder:text-slate-400 bg-transparent"
                />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="text-sm font-medium text-dark">
                Email
              </label>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
                <Mail size={17} className="text-slate-400" />
                <input
                  id="email"
                  type="email"
                  required
                  placeholder="you@example.com"
                  className="w-full text-sm outline-none placeholder:text-slate-400 bg-transparent"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="text-sm font-medium text-dark">
                Password
              </label>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
                <Lock size={17} className="text-slate-400" />
                <input
                  id="password"
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full text-sm outline-none placeholder:text-slate-400 bg-transparent"
                />
              </div>
            </div>

            <div>
              <label htmlFor="confirm" className="text-sm font-medium text-dark">
                Confirm password
              </label>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
                <Lock size={17} className="text-slate-400" />
                <input
                  id="confirm"
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full text-sm outline-none placeholder:text-slate-400 bg-transparent"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-orange hover:bg-orange-600 transition-colors text-white text-sm font-semibold py-3.5"
            >
              Create Account
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-500">
            Already have an account?{" "}
            <Link href="/login" className="font-semibold text-orange">
              Sign in
            </Link>
          </p>

          <p className="mt-8 text-center text-xs text-slate-400">
            This is a frontend prototype. Authentication is not yet connected.
          </p>
        </div>
      </section>
      <Footer />
    </>
  );
}
