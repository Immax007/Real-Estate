import Image from "next/image";
import Link from "next/link";
import {
  Bed,
  Bath,
  Ruler,
  MapPin,
  Home,
  ArrowLeft,
  Phone,
  CalendarCheck,
  SearchX,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { properties } from "@/data/properties";

export function generateStaticParams() {
  return properties.map((property) => ({ id: String(property.id) }));
}

export default function PropertyDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const property = properties.find((p) => p.id === Number(params.id));

  if (!property) {
    return (
      <>
        <Navbar />
        <section className="container-x py-24 flex flex-col items-center text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-orange-50 text-orange mb-4">
            <SearchX size={26} />
          </span>
          <h1 className="text-2xl font-bold text-dark">Property not found</h1>
          <p className="mt-2 text-sm text-slate-500 max-w-sm">
            This listing may have been removed or the link is incorrect.
          </p>
          <Link
            href="/properties"
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-orange text-white text-sm font-semibold px-5 py-3"
          >
            <ArrowLeft size={16} />
            Back to Properties
          </Link>
        </section>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />
      <section className="container-x py-8 sm:py-12">
        <Link
          href="/properties"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-dark transition-colors"
        >
          <ArrowLeft size={15} />
          Back to Properties
        </Link>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2">
            <div className="relative h-64 sm:h-96 rounded-2xl overflow-hidden">
              <Image
                src={property.image}
                alt={property.title}
                fill
                sizes="(max-width: 1024px) 100vw, 66vw"
                className="object-cover"
                priority
              />
              <span className="absolute top-4 left-4 rounded-md bg-white px-3 py-1.5 text-xs font-semibold text-dark shadow-sm">
                {property.listingType}
              </span>
            </div>

            <div className="mt-6">
              <h1 className="text-2xl sm:text-3xl font-bold text-dark">
                {property.title}
              </h1>
              <p className="mt-2 flex items-center gap-1.5 text-sm text-slate-500">
                <MapPin size={15} />
                {property.location}, {property.city}
              </p>

              <div className="mt-6 flex flex-wrap gap-6 border-y border-slate-100 py-5">
                <span className="flex items-center gap-2 text-sm text-slate-700">
                  <Bed size={18} className="text-orange" />
                  {property.bedrooms} Bedrooms
                </span>
                <span className="flex items-center gap-2 text-sm text-slate-700">
                  <Bath size={18} className="text-orange" />
                  {property.bathrooms} Bathrooms
                </span>
                <span className="flex items-center gap-2 text-sm text-slate-700">
                  <Ruler size={18} className="text-orange" />
                  {property.area}
                </span>
                <span className="flex items-center gap-2 text-sm text-slate-700">
                  <Home size={18} className="text-orange" />
                  {property.type}
                </span>
              </div>

              <div className="mt-6">
                <h2 className="text-lg font-semibold text-dark">Description</h2>
                <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed">
                  {property.description}
                </p>
              </div>
            </div>
          </div>

          <aside className="lg:col-span-1">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 sticky top-24">
              <p className="text-sm text-slate-500">Price</p>
              <p className="mt-1 text-3xl font-bold text-orange">
                {property.priceLabel}
              </p>

              <div className="mt-6 flex flex-col gap-3">
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 rounded-lg bg-orange hover:bg-orange-600 transition-colors text-white text-sm font-semibold py-3.5"
                >
                  <Phone size={16} />
                  Contact Agent
                </button>
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors text-dark text-sm font-semibold py-3.5"
                >
                  <CalendarCheck size={16} />
                  Schedule Inspection
                </button>
              </div>

              <p className="mt-5 text-xs text-slate-400 leading-relaxed">
                Agent messaging and inspection scheduling are coming soon.
                This is currently a frontend prototype.
              </p>
            </div>
          </aside>
        </div>
      </section>
      <Footer />
    </>
  );
}
