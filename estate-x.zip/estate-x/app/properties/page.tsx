import { Suspense } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertiesBrowser from "./PropertiesBrowser";

export const metadata = {
  title: "Properties | EstateX",
  description: "Browse verified properties for sale and rent across Lagos.",
};

export default function PropertiesPage() {
  return (
    <>
      <Navbar />
      <Suspense fallback={null}>
        <PropertiesBrowser />
      </Suspense>
      <Footer />
    </>
  );
}
