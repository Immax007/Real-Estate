"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { SearchX, SlidersHorizontal } from "lucide-react";
import PropertyCard from "@/components/PropertyCard";
import SectionHeading from "@/components/SectionHeading";
import { properties } from "@/data/properties";

const propertyTypes = ["Any Type", "Apartment", "House", "Villa", "Land", "Commercial"];
const listingTypes = ["Any Purpose", "For Sale", "For Rent", "Shortlet"];

export default function PropertiesBrowser() {
  const searchParams = useSearchParams();

  const [query, setQuery] = useState(searchParams.get("location") ?? "");
  const [type, setType] = useState(searchParams.get("type") ?? "Any Type");
  const [listingType, setListingType] = useState(() => {
    const purpose = searchParams.get("purpose");
    if (purpose === "Buy") return "For Sale";
    if (purpose === "Rent") return "For Rent";
    if (purpose === "Shortlet") return "Shortlet";
    return "Any Purpose";
  });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return properties.filter((property) => {
      const matchesQuery =
        !q ||
        property.title.toLowerCase().includes(q) ||
        property.location.toLowerCase().includes(q) ||
        property.city.toLowerCase().includes(q);
      const matchesType = type === "Any Type" || property.type === type;
      const matchesListingType =
        listingType === "Any Purpose" || property.listingType === listingType;
      return matchesQuery && matchesType && matchesListingType;
    });
  }, [query, type, listingType]);

  return (
    <section className="container-x py-12 sm:py-16">
      <SectionHeading
        eyebrow="Marketplace"
        heading="Find your next property"
        description="Search and filter verified listings from agents across Lagos."
      />

      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row gap-3">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title or location"
            className="flex-1 rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-orange transition-colors"
          />
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-orange transition-colors bg-white text-dark lg:w-52"
          >
            {propertyTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          <select
            value={listingType}
            onChange={(e) => setListingType(e.target.value)}
            className="rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-orange transition-colors bg-white text-dark lg:w-52"
          >
            {listingTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          <button
            type="button"
            className="flex items-center justify-center gap-2 rounded-xl bg-orange hover:bg-orange-600 transition-colors text-white text-sm font-semibold px-6 py-3 shrink-0"
          >
            <SlidersHorizontal size={16} />
            Filter
          </button>
        </div>
      </div>

      <p className="mt-6 text-sm text-slate-500">
        {filtered.length} {filtered.length === 1 ? "property" : "properties"} found
      </p>

      {filtered.length > 0 ? (
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
      ) : (
        <div className="mt-6 flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 py-20 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-orange-50 text-orange mb-4">
            <SearchX size={26} />
          </span>
          <h3 className="text-lg font-semibold text-dark">No properties match your search</h3>
          <p className="mt-1.5 text-sm text-slate-500 max-w-sm">
            Try a different location or clear a filter to see more listings.
          </p>
          <button
            type="button"
            onClick={() => {
              setQuery("");
              setType("Any Type");
              setListingType("Any Purpose");
            }}
            className="mt-5 text-sm font-semibold text-orange"
          >
            Clear all filters
          </button>
        </div>
      )}
    </section>
  );
}
