"use client";

import { FormEvent } from "react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";

export default function ContactPage() {
  function handleSubmit(e: FormEvent) {
    e.preventDefault();
  }

  return (
    <>
      <Navbar />
      <section className="container-x py-12 sm:py-16">
        <SectionHeading
          eyebrow="Get in touch"
          heading="We'd love to hear from you"
          description="Questions about a listing, an agent, or EstateX itself? Send us a message."
        />

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-1 space-y-5">
            <div className="flex items-start gap-3 rounded-2xl border border-slate-200 p-5">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange shrink-0">
                <Mail size={18} />
              </span>
              <div>
                <p className="text-sm font-semibold text-dark">Email</p>
                <p className="text-sm text-slate-500">hello@estatex.ng</p>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-2xl border border-slate-200 p-5">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange shrink-0">
                <Phone size={18} />
              </span>
              <div>
                <p className="text-sm font-semibold text-dark">Phone</p>
                <p className="text-sm text-slate-500">+234 801 234 5678</p>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-2xl border border-slate-200 p-5">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange shrink-0">
                <MapPin size={18} />
              </span>
              <div>
                <p className="text-sm font-semibold text-dark">Office</p>
                <p className="text-sm text-slate-500">Lagos, Nigeria</p>
              </div>
            </div>
          </div>

          <form
            onSubmit={handleSubmit}
            className="lg:col-span-2 rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="text-sm font-medium text-dark">
                  Name
                </label>
                <input
                  id="name"
                  type="text"
                  required
                  placeholder="Your full name"
                  className="mt-1.5 w-full rounded-xl border border-slate-200 px-3.5 py-3 text-sm outline-none focus:border-orange transition-colors placeholder:text-slate-400"
                />
              </div>
              <div>
                <label htmlFor="email" className="text-sm font-medium text-dark">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  placeholder="you@example.com"
                  className="mt-1.5 w-full rounded-xl border border-slate-200 px-3.5 py-3 text-sm outline-none focus:border-orange transition-colors placeholder:text-slate-400"
                />
              </div>
            </div>

            <div>
              <label htmlFor="subject" className="text-sm font-medium text-dark">
                Subject
              </label>
              <input
                id="subject"
                type="text"
                required
                placeholder="How can we help?"
                className="mt-1.5 w-full rounded-xl border border-slate-200 px-3.5 py-3 text-sm outline-none focus:border-orange transition-colors placeholder:text-slate-400"
              />
            </div>

            <div>
              <label htmlFor="message" className="text-sm font-medium text-dark">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={5}
                placeholder="Tell us a bit more..."
                className="mt-1.5 w-full rounded-xl border border-slate-200 px-3.5 py-3 text-sm outline-none focus:border-orange transition-colors placeholder:text-slate-400 resize-none"
              />
            </div>

            <button
              type="submit"
              className="flex items-center justify-center gap-2 rounded-xl bg-orange hover:bg-orange-600 transition-colors text-white text-sm font-semibold px-6 py-3.5 w-full sm:w-auto"
            >
              <Send size={16} />
              Send Message
            </button>
          </form>
        </div>
      </section>
      <Footer />
    </>
  );
}
