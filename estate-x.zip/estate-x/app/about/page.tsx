import { ShieldCheck, Users2, Gem } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";

export const metadata = {
  title: "About | EstateX",
  description: "Learn how EstateX helps people find homes and connect with trusted agents in Lagos.",
};

const pillars = [
  {
    icon: ShieldCheck,
    title: "Trust",
    description:
      "Every property and agent on EstateX is verified before it appears in search results, so you can browse with confidence.",
  },
  {
    icon: Users2,
    title: "Community",
    description:
      "We connect buyers, tenants and agents across Lagos, building relationships that outlast a single transaction.",
  },
  {
    icon: Gem,
    title: "Quality Properties",
    description:
      "From starter apartments to executive penthouses, our listings are curated to match real budgets and real neighbourhoods.",
  },
];

export default function AboutPage() {
  return (
    <>
      <Navbar />

      <section className="bg-dark">
        <div className="container-x py-20 sm:py-28 text-center">
          <h1 className="text-3xl sm:text-5xl font-bold text-white max-w-2xl mx-auto leading-tight">
            Real estate made simpler.
          </h1>
          <p className="mt-5 text-slate-300 max-w-xl mx-auto text-base sm:text-lg">
            EstateX helps people discover properties and connect with trusted
            agents, without the usual back-and-forth of finding a home in
            Lagos.
          </p>
        </div>
      </section>

      <section className="container-x py-16 sm:py-20">
        <SectionHeading
          eyebrow="Our approach"
          heading="What EstateX stands for"
          description="Three principles guide every listing we publish and every agent we work with."
        />

        <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-6">
          {pillars.map(({ icon: Icon, title, description }) => (
            <div
              key={title}
              className="rounded-2xl border border-slate-200 p-7 hover:shadow-card transition-shadow"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-orange-50 text-orange">
                <Icon size={22} />
              </span>
              <h3 className="mt-5 font-semibold text-dark text-lg">{title}</h3>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                {description}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-x pb-16 sm:pb-20">
        <div className="rounded-2xl bg-slate-50 border border-slate-100 px-6 py-12 sm:px-14 sm:py-14">
          <div className="max-w-2xl">
            <h2 className="text-2xl sm:text-3xl font-bold text-dark">
              Built for the Lagos property market
            </h2>
            <p className="mt-4 text-slate-600 leading-relaxed">
              From Lekki and Ikoyi to Yaba and Ajah, we work directly with
              agents who understand each neighbourhood — its pricing,
              paperwork, and pace. Our goal is a marketplace where finding a
              home feels straightforward, not stressful.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
