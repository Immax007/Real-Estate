"use client";

import Link from "next/link";
import { FormEvent } from "react";
import { Home, Mail, Lock } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function LoginPage() {
  function handleSubmit(e: FormEvent) {
    e.preventDefault();
  }

  return (
    <>
      <Navbar />
      <section className="container-x py-14 sm:py-20 flex justify-center">
        <div className="w-full max-w-md">
          <div className="flex flex-col items-center text-center">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange text-white mb-4">
              <Home size={20} strokeWidth={2.5} />
            </span>
            <h1 className="text-2xl font-bold text-dark">Welcome back</h1>
            <p className="mt-2 text-sm text-slate-500">
              Sign in to manage your saved properties and messages.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div>
              <label htmlFor="email" className="text-sm font-medium text-dark">
                Email
              </label>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
                <Mail size={17} className="text-slate-400" />
                <input
                  id="email"
                  type="email"
                  required
                  placeholder="you@example.com"
                  className="w-full text-sm outline-none placeholder:text-slate-400 bg-transparent"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="text-sm font-medium text-dark">
                Password
              </label>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-slate-200 px-3.5 py-3 focus-within:border-orange transition-colors">
                <Lock size={17} className="text-slate-400" />
                <input
                  id="password"
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full text-sm outline-none placeholder:text-slate-400 bg-transparent"
                />
              </div>
              <div className="mt-2 text-right">
                <Link href="#" className="text-xs font-medium text-orange">
                  Forgot password?
                </Link>
              </div>
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-orange hover:bg-orange-600 transition-colors text-white text-sm font-semibold py-3.5"
            >
              Sign In
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-500">
            Don&apos;t have an account?{" "}
            <Link href="/register" className="font-semibold text-orange">
              Create an account
            </Link>
          </p>

          <p className="mt-8 text-center text-xs text-slate-400">
            This is a frontend prototype. Authentication is not yet connected.
          </p>
        </div>
      </section>
      <Footer />
    </>
  );
}
