"use client";

import { useState } from "react";
import {
  LayoutGrid,
  Heart,
  MessageSquare,
  CalendarCheck,
  User,
  Menu,
  X,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import { properties } from "@/data/properties";

const navItems = [
  { label: "Overview", icon: LayoutGrid },
  { label: "Saved Properties", icon: Heart },
  { label: "Messages", icon: MessageSquare },
  { label: "Inspections", icon: CalendarCheck },
  { label: "Profile", icon: User },
];

export default function DashboardPage() {
  const [active, setActive] = useState("Overview");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const saved = properties.slice(0, 3);

  return (
    <>
      <Navbar />
      <section className="container-x py-8 sm:py-12">
        <div className="flex items-center justify-between lg:hidden mb-4">
          <h1 className="text-xl font-bold text-dark">Dashboard</h1>
          <button
            type="button"
            onClick={() => setMobileNavOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-dark"
            aria-label="Toggle dashboard navigation"
          >
            {mobileNavOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-8">
          <aside
            className={`${
              mobileNavOpen ? "block" : "hidden"
            } lg:block rounded-2xl border border-slate-200 p-3 h-fit`}
          >
            <nav className="flex flex-col gap-1">
              {navItems.map(({ label, icon: Icon }) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => {
                    setActive(label);
                    setMobileNavOpen(false);
                  }}
                  className={`flex items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors ${
                    active === label
                      ? "bg-orange text-white"
                      : "text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  <Icon size={17} />
                  {label}
                </button>
              ))}
            </nav>
          </aside>

          <div>
            <h1 className="hidden lg:block text-2xl font-bold text-dark mb-6">
              Overview
            </h1>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="rounded-2xl border border-slate-200 p-6">
                <p className="text-sm text-slate-500">Saved Properties</p>
                <p className="mt-2 text-3xl font-bold text-dark">12</p>
              </div>
              <div className="rounded-2xl border border-slate-200 p-6">
                <p className="text-sm text-slate-500">Messages</p>
                <p className="mt-2 text-3xl font-bold text-dark">5</p>
              </div>
              <div className="rounded-2xl border border-slate-200 p-6">
                <p className="text-sm text-slate-500">Inspections</p>
                <p className="mt-2 text-3xl font-bold text-dark">3</p>
              </div>
            </div>

            <div className="mt-10">
              <h2 className="text-lg font-semibold text-dark mb-5">
                Saved Properties
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {saved.map((property) => (
                  <PropertyCard key={property.id} property={property} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
