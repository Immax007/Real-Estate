import Image from "next/image";
import { BadgeCheck, MapPin, Phone } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";

export const metadata = {
  title: "Agents | EstateX",
  description: "Meet the verified real-estate agents on EstateX.",
};

const agents = [
  {
    name: "Chidinma Eze",
    location: "Lekki, Lagos",
    description:
      "Specialises in luxury duplexes and gated estates across the Lekki-Epe corridor, with 8 years in Lagos real estate.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&q=80",
  },
  {
    name: "Tunde Bakare",
    location: "Ikoyi, Lagos",
    description:
      "Focused on high-end family homes and waterfront properties in Ikoyi and Banana Island.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&q=80",
  },
  {
    name: "Amaka Nwosu",
    location: "Victoria Island, Lagos",
    description:
      "Helps corporate tenants and expatriates find serviced apartments on Victoria Island.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&q=80",
  },
  {
    name: "Ibrahim Suleiman",
    location: "Ajah, Lagos",
    description:
      "Works with first-time buyers on affordable homes and villas in the fast-growing Ajah axis.",
    image: "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400&q=80",
  },
  {
    name: "Ngozi Adeyemi",
    location: "Yaba, Lagos",
    description:
      "Rental specialist for young professionals and students around the Yaba tech corridor.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&q=80",
  },
  {
    name: "Emeka Chukwu",
    location: "Banana Island, Lagos",
    description:
      "Represents premium penthouse and waterfront listings for high-net-worth buyers.",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&q=80",
  },
];

export default function AgentsPage() {
  return (
    <>
      <Navbar />
      <section className="container-x py-12 sm:py-16">
        <SectionHeading
          eyebrow="Our network"
          heading="Meet our agents"
          description="Every agent on EstateX is vetted and verified before they can list a property."
        />

        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent) => (
            <div
              key={agent.name}
              className="rounded-2xl border border-slate-200 bg-white p-6 shadow-card hover:shadow-cardHover transition-shadow"
            >
              <div className="flex items-center gap-4">
                <div className="relative h-14 w-14 rounded-full overflow-hidden shrink-0">
                  <Image
                    src={agent.image}
                    alt={agent.name}
                    fill
                    sizes="56px"
                    className="object-cover"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-semibold text-dark">{agent.name}</h3>
                    <BadgeCheck size={16} className="text-orange" />
                  </div>
                  <p className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                    <MapPin size={12} />
                    {agent.location}
                  </p>
                </div>
              </div>

              <p className="mt-4 text-sm text-slate-600 leading-relaxed">
                {agent.description}
              </p>

              <button
                type="button"
                className="mt-5 flex items-center justify-center gap-2 w-full rounded-lg border border-slate-200 py-2.5 text-sm font-semibold text-dark hover:bg-orange hover:text-white hover:border-orange transition-colors"
              >
                <Phone size={15} />
                Contact Agent
              </button>
            </div>
          ))}
        </div>
      </section>
      <Footer />
    </>
  );
}
